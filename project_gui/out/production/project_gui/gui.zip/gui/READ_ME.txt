Hello user!
Frantisek is a guy - a graphic user interface coded in Java. 

What does Frantisek contain and what can it do?

Frantisek contains one canvas to which you can add nodes. It draws edges between the verices automatically.
You can add a node by clicking at white area. 
If you click at a node, it will be selected. If you click at a selected node, it wil be deselected. 
You can also change the position of a node - simply drag it where you want it to be. 

Next to the canvas with nodes is a list of nodes as they are currently ordered. This list displays the coordinates of a node and its current color. 
By clicking the arrows next to the list, you can switch the nodes and alter their order. 

Frantisek can add colours to your nodes. On the right side is a table of colors from which you can choose the color. 
Don't like the displayed colors? Pick one yourself by clicking at "Insert Color" button and writing colour's hexadecimal value or a predefined colour name. 
Or you can use Color picker which also displays the currently selected color. 
Using a "F" key you can colorize the currently selected vertex using the selected color. 

Using buttons uder the list of nodes, you can insert a node at given coordinates, delete selected node, rotate the whole polygon (vertices and edges alike), 
change the size of the polygon, or move the polygon. 

In the upper rigt corner is a menu. It enables to creat a new polygon with given number of vertices (and currently selected color), open, save, or exit the program. 

Have fun. 

The creator

